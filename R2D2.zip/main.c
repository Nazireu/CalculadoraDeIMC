#include <stdio.h>
#include <stdlib.h>

int main()
{
	float altura,peso,imc;
	printf("Informe peso (em kilogramas): ");
	scanf("%f",&peso);
	printf("Informe altura (em metros): ");
	scanf("%f",&altura);
	imc = peso / (altura * altura);
	printf("\nIMC: %.2f\n\n",imc);

  if (imc<18.5)
  {
      printf("Abaixo do peso ideal");

  }

  if ( (imc>=18.5) && (imc<25.0) )
  {
    printf("Peso normal");
  }
  
  if ( (imc>=25.0) && (imc<30.0) )
  {
    printf("Sobrepeso");
  }
  
  if ( (imc>=30.0) && (imc<35.0) )
  {
    printf("Obesisdade grau 1");
  }
  
  if ( (imc>=35.0) && (imc<40.0) )
  {
  printf("Obesidade grau 2");
  }
  
  if (imc>=40.0)
  {
    printf("Obesidade grau 3 ou Morbita");
  }
  
	return 0;	
}